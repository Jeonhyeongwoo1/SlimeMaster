namespace SlimeMaster.Interface
{
    public interface IView
    {
        
    }
}