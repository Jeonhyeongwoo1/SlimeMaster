namespace SlimeMaster.Interface
{
    public interface IModel
    {
        
    }
}