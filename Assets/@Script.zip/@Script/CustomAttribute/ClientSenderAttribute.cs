using System;

namespace SlimeMaster.Attribute
{
    [AttributeUsage(AttributeTargets.Interface, AllowMultiple = false)]
    public class ClientSenderAttribute : System.Attribute
    {
    }
}