using SlimeMaster.Popup;
using UnityEngine;

namespace SlimeMaster.OutGame.Popup
{
    public class GameContinuePopup : BasePopup
    {
    }
}