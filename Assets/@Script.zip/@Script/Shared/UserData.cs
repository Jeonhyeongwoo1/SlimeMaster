namespace SlimeMaster.Shared.Data
{
    public class UserData
    {
        
    }
}