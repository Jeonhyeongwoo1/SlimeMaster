namespace SlimeMaster.InGame.Controller
{
    public class DropBoxController : DropItemController
    {
        
    }
}