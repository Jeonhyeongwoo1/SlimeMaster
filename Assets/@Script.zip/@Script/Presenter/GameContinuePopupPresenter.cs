using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SlimeMaster.Presenter
{
    public class GameContinuePopupPresenter : BasePresenter
    {
        

        public void Initialize()
        {
            
        }
        
        
    }
}