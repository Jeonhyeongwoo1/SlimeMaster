namespace SlimeMaster.Presenter
{
    public class BasePresenter
    {
        
    }
}