
namespace SlimeMaster.Key
{
    public static class DBKey
    {
        public static string UserDB = "user";
        public static string ShopDB = "shop";
        public static string CheckoutDB = "checkout";
    }
}