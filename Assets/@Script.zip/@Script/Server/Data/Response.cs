using SlimeMaster.Enum;

namespace SlimeMaster.Shared
{
    public class Response
    {
        public ServerErrorCode responseCode;
        public string errorMessage;
    }
}