using SlimeMaster.Firebase.Data;

namespace SlimeMaster.Shared.Data
{
    public class StageClearResponse : Response
    {
        public DBItemData ItemData;
        public DBStageData StageData;
    }
}