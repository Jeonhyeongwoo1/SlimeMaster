using SlimeMaster.Firebase.Data;

namespace SlimeMaster.Shared.Data
{
    public class AchievementResponse : Response
    {
        public DBItemData RewardItemData;
        public DBAchievementContainerData DBAchievementContainerData;
    }
}