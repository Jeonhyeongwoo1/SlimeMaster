
namespace SlimeMaster.Interface
{
    public interface IClientSender
    {
        
    }
}